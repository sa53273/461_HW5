import { useState } from 'react';


function Project(props){
    var hw1 = props.hw1init;
    var hw2 = props.hw2init;
    const [thing, setThing] = useState(null) || {};
    const [thing2, setThing2] = useState(null) || {};
    const [status, setStatus] = useState("Join");
    const currUsers = ["list, ", "of, ", "authorized, ", "users "];
    function checkInorOut(props) {
        var add = props.add;
        if(props.box === 2 || props.box === 4) add = -add;
        let sum = props.init + props.add;
        if(sum < 0) sum = 0;
        else if (sum > 100) sum = 100;
        switch(props.box){
            case 1: hw1 = sum;
            case 2: hw1 = sum;
            case 3: hw2 = sum;
            case 4: hw2 = sum;
        }

    }
    return <section
       className = "project">
       <div class = "flexbox-container">
            <div class ="vBox2">
            <h2 class = "resizable">{props.name}</h2>
            <p class = "regularText">Users: {currUsers} </p>
            </div>
            <div class ="vBox">
                <p class = "regularText">HWSet1:    {hw1}/100</p>
                <p class = "regularText">HWSet1:    {hw2}/100</p>
            </div>
            <div class ="vBox">
            <input id="in1" type="number" defaultValue="0"style={{width: "50px"}}/>
            <input id="in2" type="number" defaultValue="0"style={{width: "50px"}}/>
            </div>
            <div class ="vBox">
                <button id = "cIn1" class = "regularButton" >Check In</button>
                <button id = "cIn2" class = "regularButton">Check In</button>
            </div>
            <div class ="vBox">
                <button id = "cIn2" class = "regularButton">Check Out</button>
                <button id = "cOut2" class = "regularButton">Check Out</button>
            </div>
            <button class="regularButton">{status}</button>
       </div>

    </section>
}

export default function ProjectPage() {
    return (
    <>
        <h1 class = "center"> View Projects </h1>
        <Project name = "Project 1" hw1init = "30" hw2init = "40"/>
        <Project name = "Project 2" hw1init = "25" hw2init = "0"/>
        <Project name = "Project 3" hw1init = "0" hw2init = "45"/>
    </>
    );
}